package com.kilobolt.robotgame;

public class Heliboy extends Enemy {

	public Heliboy(int centerX, int centerY) {

		setCenterX(centerX);
		setCenterY(centerY);

	}

}
